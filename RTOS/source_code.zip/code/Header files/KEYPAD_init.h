/******************************************************
 *  Demonstration program to read the XC4602 Jaycar Keypad
 *  on a BeagleBone Black (BBB) running QNX 6.60 that matches the lecture notes
 *
 *
 *	This version uses and ISR to clear the IRQ
 *
 *	uses InterruptAttach()
 *
 *  The Keypad uses the TTP229-BSF TonTouch Chip and can be
 *  purchased from Jaycar (XC4602). Make sure it is in 16 key
 *  mode by bridging our the two pins (pair 3 on P1 on keypad)
 *
 *  When Key press is detected a hardware interrupt will be fired
 *  IRQ 99 (top part of GPIO1, ie IO bit 28 of GPIO1). The key
 *  will be decoded and a thread will start which controls the
 *  4 LEDS on the beaglebone to switch on and off for a 100 ms
 *  duration to indicate a valid key has been pressed and decoded.
 *
 *  XC4602 pin     -> BeagleBone Black Pin
 *  VCC - VDD_3V3B -> pin P9_03 or P9_04
 *  GND - DGND     -> pin P9_01 or P9_02
 * 	SCL - GPIO1_16 -> pin P9_15
 * 	SD0 - GPIO1_28 -> pin P9_12
 *
 *  Author: Samuel Ippolito
 *  Date:   17-08-2018
 *
 *****************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <hw/inout.h>      // for in32() and out32();
#include <sys/mman.h>      // for mmap_device_io();
#include <stdint.h>        // for unit32 types
#include <sys/neutrino.h>  // for ThreadCtl( _NTO_TCTL_IO_PRIV , NULL)
#include <sched.h>
#include <sys/procmgr.h>
#include "dataStruct.h"

#define AM335X_CONTROL_MODULE_BASE   (uint64_t) 0x44E10000
#define AM335X_CONTROL_MODULE_SIZE   (size_t)   0x00001448
#define AM335X_GPIO_SIZE             (uint64_t) 0x00001000
#define AM335X_GPIO1_BASE            (size_t)   0x4804C000

#define LED0          (1<<21)   // GPIO1_21
#define LED1          (1<<22)   // GPIO1_22
#define LED2          (1<<23)   // GPIO1_23
#define LED3          (1<<24)   // GPIO1_24

#define SD0 (1<<28)  // SD0 is connected to GPIO1_28
#define SCL (1<<16)  // SCL is connected to GPIO1_16


#define GPIO_OE        0x134
#define GPIO_DATAIN    0x138
#define GPIO_DATAOUT   0x13C

#define GPIO_IRQSTATUS_SET_1 0x38   // enable interrupt generation
#define GPIO_IRQWAKEN_1      0x48   // Wakeup Enable for Interrupt Line
#define GPIO_FALLINGDETECT   0x14C  // set falling edge trigger
#define GPIO_CLEARDATAOUT    0x190  // clear data out Register
#define GPIO_IRQSTATUS_1     0x30   // clear any prior IRQs

#define GPIO1_IRQ 99  // TRG page 465 list the IRQs for the am335x


#define P9_12_pinConfig 0x878 //  conf_gpmc_ben1 (TRM pp 1364) for GPIO1_28,  P9_12

// GPMC_A1_Configuration
#define PIN_MODE_0   0x00
#define PIN_MODE_1   0x01
#define PIN_MODE_2   0x02
#define PIN_MODE_3   0x03
#define PIN_MODE_4   0x04
#define PIN_MODE_5   0x05
#define PIN_MODE_6   0x06
#define PIN_MODE_7   0x07

// PIN MUX Configuration strut values  (page 1420 from TRM)
#define PU_ENABLE    0x00
#define PU_DISABLE   0x01
#define PU_PULL_UP   0x01
#define PU_PULL_DOWN 0x00
#define RECV_ENABLE  0x01
#define RECV_DISABLE 0x00
#define SLEW_FAST    0x00
#define SLEW_SLOW    0x01



void strobe_SCL(uintptr_t gpio_port_add) {
   uint32_t PortData;
   PortData = in32(gpio_port_add + GPIO_DATAOUT);// value that is currently on the GPIO port
   PortData &= ~(SCL);
   out32(gpio_port_add + GPIO_DATAOUT, PortData);// Clock low
   delaySCL();

   PortData  = in32(gpio_port_add + GPIO_DATAOUT);// get port value
   PortData |= SCL;// Clock high
   out32(gpio_port_add + GPIO_DATAOUT, PortData);
   delaySCL();
}


// Thread used to Flash the 4 LEDs on the BeagleBone for 100ms
void *Flash_LED0_ex(void *notused)
{
	pthread_detach(pthread_self());  // no need for this thread to join
	uintptr_t gpio1_port = mmap_device_io(AM335X_GPIO_SIZE, AM335X_GPIO1_BASE);

	uintptr_t val;
	// Write GPIO data output register
	val  = in32(gpio1_port + GPIO_DATAOUT);
	val |= (LED3);
	out32(gpio1_port + GPIO_DATAOUT, val);

	usleep(100000);  // 100 ms wait
	//sched_yield();  // if used without the usleep, this line will flash the LEDS for ~4ms

	val  = in32(gpio1_port + GPIO_DATAOUT);
	val &= ~(LED3);
	out32(gpio1_port + GPIO_DATAOUT, val);

	munmap_device_io(gpio1_port, AM335X_GPIO_SIZE);

}


void delaySCL()  {// Small delay used to get timing correct for BBB
  volatile int i, a;
  for(i=0;i<0x1F;i++) // 0x1F results in a delay that sets F_SCL to ~480 kHz
  {   // i*1 is faster than i+1 (i+1 results in F_SCL ~454 kHz, whereas i*1 is the same as a=i)
     a = i;
  }
  // usleep(1);  //why doesn't this work? Ans: Results in a period of 4ms as
  // fastest time, which is 250Hz (This is to slow for the TTP229 chip as it
  // requires F_SCL to be between 1 kHz and 512 kHz)
}

uint32_t KeypadReadIObit(uintptr_t gpio_base, uint32_t BitsToRead)  {
   volatile uint32_t val = 0;
   val  = in32(gpio_base + GPIO_DATAIN);// value that is currently on the GPIO port

   val &= BitsToRead; // mask bit
   //val = val >> (BitsToRead % 2);
   //return val;
   if(val==BitsToRead)
	   return 1;
   else
	   return 0;
}

int DecodeKeyValue(uint32_t word)
{
	int value = 0;
	switch(word)
	{
		case 0x01:
			value = 1;
			printf("Key  1 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x02:
			value = 2;
			printf("Key  2 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x04:
			value = 3;
			printf("Key  3 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x08:
			value = 4;
			printf("Key  4 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x10:
			value = 5;
			printf("Key  5 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x20:
			value = 6;
			printf("Key  6 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x40:
			value = 7;
			printf("Key  7 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x80:
			value = 8;
			printf("Key  8 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x100:
			value = 9;
			printf("Key  9 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x200:
			value = 10;
			printf("Key 10 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x400:
			value = 11;
			printf("Key 11 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x800:
			value = 12;
			printf("Key 12 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x1000:
			value = 13;
			printf("Key 13 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x2000:
			value = 14;
			printf("Key 14 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x4000:
			value = 15;
			printf("Key 15 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			break;
		case 0x8000:
			value = 16;
			printf("Key 16 pressed\n");
			pthread_create(NULL, NULL, Flash_LED0_ex, NULL); // flash LED
			usleep(1); // do this so we only fire once
			break;
		case 0x00:  // key release event (do nothing)
			break;
		default:
			printf("Key pressed could not be determined - %lu\n", word);
	}
	return value;
}
/*
 *
 *
 * Here is the ISR
 *
 *
 *
 */
typedef struct
{
	int count_thread;
	uintptr_t gpio1_base;
	struct sigevent pevent; // remember to fill in "event" structure in main
}ISR_data;

// create global struct to share data between threads
ISR_data ISR_area_data;

const struct sigevent* Inthandler( void* area, int id )
{
	// 	"Do not call any functions in ISR that call kernerl - including printf()
	//struct sigevent *pevent = (struct sigevent *) area;
	ISR_data *p_ISR_data = (ISR_data *) area;

	InterruptMask(GPIO1_IRQ, id);  // Disable all hardware interrupt

	// must do this in the ISR  (else stack over flow and system will crash
	out32(p_ISR_data->gpio1_base + GPIO_IRQSTATUS_1, SD0); //clear IRQ

	// do this to tell us how many times this handler gets called
	p_ISR_data->count_thread++;
	// got IRQ.
	// work out what it came from

    InterruptUnmask(GPIO1_IRQ, id);  // Enable a hardware interrupt

    // return a pointer to an event structure (preinitialized
    // by main) that contains SIGEV_INTR as its notification type.
    // This causes the InterruptWait in "int_thread" to unblock.
	return (&p_ISR_data->pevent);
}



uintptr_t KEYPAD_init ()
{
	printf("\nKeypad set up starts\n");

  uintptr_t control_module = mmap_device_io(AM335X_CONTROL_MODULE_SIZE,
                                                               AM335X_CONTROL_MODULE_BASE);
  uintptr_t gpio1_base = mmap_device_io(AM335X_GPIO_SIZE          , AM335X_GPIO1_BASE);

  // initalise the global stuct
  ISR_area_data.count_thread = 0;
  ISR_area_data.gpio1_base = gpio1_base;


  memset(&ISR_area_data.pevent, 0, sizeof(ISR_area_data.pevent));
  SIGEV_INTR_INIT (&ISR_area_data.pevent);
  ISR_area_data.pevent.sigev_notify = SIGEV_INTR;  // Setup for external interrupt



	// we also need to have the PROCMGR_AID_INTERRUPT and PROCMGR_AID_IO abilities enabled. For more information, see procmgr_ability().
  ThreadCtl( _NTO_TCTL_IO_PRIV , 1);// Request I/O privileges  for QNX7;

  //procmgr_ability( 0, PROCMGR_AID_INTERRUPT | PROCMGR_AID_IO);			// error?


  if( (control_module)&&(gpio1_base) )
  {

    volatile uint32_t val = 0;

    // set DDR for LEDs to output and GPIO_28 to input
    val = in32(gpio1_base + GPIO_OE); // read in current setup for GPIO1 port
    val |= 1<<28;                     // set IO_BIT_28 high (1=input, 0=output)
    out32(gpio1_base + GPIO_OE, val); // write value to input enable for data pins
    val &= ~(LED3);    // write value to output enable
    out32(gpio1_base + GPIO_OE, val); // write value to output enable for LED pins

    val = in32(gpio1_base + GPIO_OE);
    val &= ~SCL;                      // 0 for output
    out32(gpio1_base + GPIO_OE, val); // write value to output enable for data pins


    val = in32(gpio1_base + GPIO_DATAOUT);
    val |= SCL;              // Set Clock Line High as per TTP229-BSF datasheet
    out32(gpio1_base + GPIO_DATAOUT, val); // for 16-Key active-Low timing diagram


    in32s(&val, 1, control_module + P9_12_pinConfig );
    printf("Original pinmux configuration for GPIO1_28 = %#010x\n", val);

    // set up pin mux for the pins we are going to use  (see page 1354 of TRM)
    volatile _CONF_MODULE_PIN pinConfigGPMC; // Pin configuration strut
    pinConfigGPMC.d32 = 0;
    // Pin MUX register default setup for input (GPIO input, disable pull up/down - Mode 7)
    pinConfigGPMC.b.conf_slewctrl = SLEW_SLOW;    // Select between faster or slower slew rate
    pinConfigGPMC.b.conf_rxactive = RECV_ENABLE;  // Input enable value for the PAD
    pinConfigGPMC.b.conf_putypesel= PU_PULL_UP;   // Pad pullup/pulldown type selection
    pinConfigGPMC.b.conf_puden = PU_ENABLE;       // Pad pullup/pulldown enable
    pinConfigGPMC.b.conf_mmode = PIN_MODE_7;      // Pad functional signal mux select 0 - 7

    // Write to PinMux registers for the GPIO1_28
    out32(control_module + P9_12_pinConfig, pinConfigGPMC.d32);
    in32s(&val, 1, control_module + P9_12_pinConfig);   // Read it back
    printf("New configuration register for GPIO1_28 = %#010x\n", val);

    // Setup IRQ for SD0 pin ( see TRM page 4871 for register list)
    out32(gpio1_base + GPIO_IRQSTATUS_SET_1, SD0);	// Write 1 to GPIO_IRQSTATUS_SET_1
    out32(gpio1_base + GPIO_IRQWAKEN_1, SD0);    	// Write 1 to GPIO_IRQWAKEN_1
    out32(gpio1_base + GPIO_FALLINGDETECT, SD0);    // set falling edge
    out32(gpio1_base + GPIO_CLEARDATAOUT, SD0);     // clear GPIO_CLEARDATAOUT
    out32(gpio1_base + GPIO_IRQSTATUS_1, SD0);      // clear any prior IRQs



    int id = 0; // Attach interrupt Event to IRQ for GPIO1B  (upper 16 bits of port)


    // Main code starts here
    //The thread that calls InterruptWait() must be the one that called InterruptAttach().
//    id = InterruptAttach (GPIO1_IRQ, Inthandler, &ISR_area_data, sizeof(ISR_area_data), _NTO_INTR_FLAGS_TRK_MSK | _NTO_INTR_FLAGS_NO_UNMASK | _NTO_INTR_FLAGS_END);
    id = InterruptAttach (GPIO1_IRQ, Inthandler, &ISR_area_data, sizeof(ISR_area_data), _NTO_INTR_FLAGS_TRK_MSK );

    InterruptUnmask(GPIO1_IRQ, id);  // Enable a hardware interrupt

    //int i = 0;
    printf( "Keypad set up completes\n");


     //munmap_device_io(control_module, AM335X_CONTROL_MODULE_SIZE);
   }
   //printf("Main Terminated...!\n");
   return gpio1_base;
 }
void *Keypad(void* data){
	TrainNodeDATA *td = (TrainNodeDATA*) data;
	uintptr_t gpio1_base = KEYPAD_init ();
	int keyValue;
	volatile uint32_t val = 0;
    while(1)
    {
    	// Block main until we get a sigevent of type: 	ISR_area_data.pevent
        InterruptWait( 0, NULL );   // block this thread until an interrupt occurs  (Wait for a hardware interrupt)

        // printf("do interrupt work here...\n");

		volatile uint32_t word = 0;
		//  confirm that SD0 is still low (that is a valid Key press event has occurred)
		val = KeypadReadIObit(gpio1_base, SD0);  // read SD0 (means data is ready)

		if(val == 0)  // start reading key value form the keypad
		{
			 word = 0;  // clear word variable

			 delaySCL(); // wait a short period of time before reading the data Tw  (10 us)

			 for(int i=0;i<16;i++)           // get data from SD0 (16 bits)
			 {
				strobe_SCL(gpio1_base);  // strobe the SCL line so we can read in data bit

				val = KeypadReadIObit(gpio1_base, SD0); // read in data bit
				val = ~val & 0x01;                      // invert bit and mask out everything but the LSB
				//printf("val[%u]=%u, ",i, val);
				word = word | (val<<i);  // add data bit to word in unique position (build word up bit by bit)
			 }
			 //printf("word=%u\n",word);
			 keyValue = DecodeKeyValue(word);
			 if(keyValue != 0){		// just to prevent assigning 0 to the variable when releasing the key
				 td->trainSENSOR = keyValue;
			 }
			 //printf("Interrupt count = %i\n", ISR_area_data.count_thread);
		}


        //sched_yield();
    }

}
