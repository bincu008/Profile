#include <stdlib.h>
#include <stdio.h>
#include <hw/inout.h>      // for in32() and out32();
#include <sys/mman.h>      // for mmap_device_io();
#include <sys/neutrino.h>  // for ThreadCtl( _NTO_TCTL_IO_PRIV , NULL);
#include <stdint.h>		   // for unit32 types
#include <pthread.h>
#include "LED_init.h"
#include "KEYPAD_init.h"
#include "LCD_init.h"
#include "dataStruct.h"


typedef struct{
	 int Gate;
	 int Indicator;
} output;

int globalReady;


void Train_node (struct TrainNodeDATA *data){
	TrainNodeDATA* state =  data;
	//pthread_mutex_lock(&state->mutex);
	switch(state->curState.state){

	case wait4train:
		//printf("State: wait4train\n");
		//printf("Waiting for train\n");
		strcpy(state->state, "S: wait4train      ");		//19 space to clear the LCD
		strcpy(state->mode, "No train, drive thr");
		sleep(1);
		if(state->trainSENSOR == 1){
			printf("Train is comming\n");
			sleep(1);
			state->curState.state = trafficClearance;
		}else{
			state->curState.state = wait4train;
		}
		//state->input = ' ';
		//state->result.Gate = 0;
		//state->result.Indicator = 0;

		break;
	case trafficClearance:
		//printf("State: trafficClearance\n");
		//printf("Clearing the traffic before closing boom gate\n");
		strcpy(state->state, "S: trafficClearance");
		strcpy(state->mode, "Train coming, cls G");
		sleep(3);
		//printf("INPUT: %c\n",state->input);
		state->curState.state = closeGate;
		//state->result.Gate = 0;
		//state->result.Indicator = 1;

		break;
	case closeGate:
		//printf("State: closeGate\n");
		//printf("Gate is closing\n");
		strcpy(state->state, "S: CloseGate       ");
		strcpy(state->mode, "Train passing      ");
		if(state->trainSENSOR == 2){
			printf("Train has passed\n");
			sleep(1);
			state->curState.state = openGate;
		}else{
			state->curState.state = closeGate;
		}
		//state->input = ' ';
		//state->result.Gate = 1;
		//state->result.Indicator = 1;
		break;
	case openGate:
		//printf("State: openGate\n");
		//printf("Gate is opening\n");
		strcpy(state->state, "S: OpenGate        ");
		strcpy(state->mode, "Gate opening       ");
		sleep(2);
		state->curState.state = wait4train;
		//state->result.Gate = 0;
		//state->result.Indicator = 0;
		break;
	}
	//globalReady = ready;
	//pthread_mutex_unlock(&state->mutex);
}
/*void *sensor(struct modState *data){
	char input;
	modState* state =  data;
	while (1){
		if (globalReady == 1){
			pthread_mutex_lock(&state->mutex);
			if (state->state == wait4train || state->state == closeGate){
				printf("Please input a condition (c for coming, p for passing):\n");
				input = getchar();
				getchar();
				state->input = input;
			}
			//sleep(1);
			//printf("INPUT: %c",input);
			//state->input = input;
			pthread_mutex_unlock(&state->mutex);
			//printf("%c\n",globalInput);
		}

	}
}*/
int main(int argc, char *argv[])
{
	printf("Train node initiates...\n");

	///////////////////////////////////////////// new
	printf("Start initializing the BeagleBone\n");
	pthread_t KP_thread;
	pthread_t LCD_th1, LCD_th3, LED_thr;
	void *reval;
	volatile uint32_t	val = 0;
	modState CurrentState = {wait4train, ' ', PTHREAD_MUTEX_INITIALIZER}; // Declaring the enum within the main
	TrainNodeDATA data = {0, "", "", LCD_init(), CurrentState};
	//LCD_connect td = LCD_init();
	int i = 0;
	uintptr_t control_module = mmap_device_io(AM335X_CONTROL_MODULE_SIZE, AM335X_CONTROL_MODULE_BASE);
	//uintptr_t gpio1_base = LED_init();
	pthread_create(&LED_thr,NULL,strobingLED,&data);
	// Keypad thread
	pthread_create(&KP_thread,NULL,Keypad,&data);
	// LCD thread
	pthread_create (&LCD_th1, NULL, LCDthread_A_ex, &data);
	//pthread_create (&LCD_th2, NULL, LCDthread_B_ex, &data);
	pthread_create (&LCD_th3, NULL, LCDthread_C_ex, &data);
	//pthread_create (&LCD_th4, NULL, LCDthread_D_ex, &data);
	procmgr_ability( 0, PROCMGR_AID_INTERRUPT | PROCMGR_AID_IO);			// source KEYPAD_init.h, must be placed in main loop since it calls the process ID
	sleep(1);
	printf("\nFinish initializing the BeagleBone\n\n");
	///////////////////////////////////////////// end new

	//int ready = 0;

 // means we will need to pass it by address
	pthread_t getChar;
	pthread_attr_t attr;
	struct sched_param th1_param;
	void *retval;
	 // Initialise thread attribute object to the default values (required)
	pthread_attr_init (&attr);
	// Explicitly set the scheduling policy to round robin
	pthread_attr_setschedpolicy (&attr, SCHED_RR);
	// Set thread priority (can be from 1..63 in QNX, default is 10)
	th1_param.sched_priority = 10;
	pthread_attr_setschedparam (&attr, &th1_param);
	 // Now set attribute to use the explicit scheduling settings
	pthread_attr_setinheritsched (&attr, PTHREAD_EXPLICIT_SCHED);
	//pthread_create(&getChar, &attr,&sensor,&CurrentState);

	while (1)
	{
		//printf("%c",&CurrentState->input);
		//printf("\n");
		Train_node(&data); // pass address
		//sensor(&CurrentState, ready);
		//printf("GATE: %d\n",CurrentState.result.Gate);
		//printf("Indicator: %d\n",CurrentState.result.Indicator);
		usleep(1);
	}
	//pthread_join(getChar, retval);
	pthread_join(KP_thread,reval);
	pthread_join(LCD_th1,reval);
	pthread_mutex_destroy(&data.td.mutex);
	//munmap_device_io(gpio1_base, AM335X_GPIO_SIZE);
	munmap_device_io(control_module, AM335X_CONTROL_MODULE_SIZE);
}

