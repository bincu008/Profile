/*
 * dataSruct.h
 *
 *  Created on: Oct 5, 2019
 *      Author: Hieu
 */

#ifndef DATASTRUCT_H_
#define DATASTRUCT_H_

enum Boomstates {
	wait4train,
	trafficClearance,
	closeGate,
	openGate
};

typedef struct{
	enum Boomstates state;
	char input;
	//output result;
	pthread_mutex_t mutex;
} modState;

typedef struct
{
	int fd;
	uint8_t Address;
	uint8_t mode;
	pthread_mutex_t mutex;
} LCD_connect;

typedef struct{
	int trainSENSOR;
	char state[20];
	char mode[20];
	LCD_connect td;
	modState curState;

} TrainNodeDATA;

typedef struct{
	int pedestrianSENSOR;
	char state[10];
	char event[9];
	char mode[9];
	LCD_connect td;

} internalDATA;



typedef union _CONF_MODULE_PIN_STRUCT   // See TRM Page 1420
{
  unsigned int d32;
  struct {    // name: field size
           unsigned int conf_mmode : 3;       // LSB
           unsigned int conf_puden : 1;
           unsigned int conf_putypesel : 1;
           unsigned int conf_rxactive : 1;
           unsigned int conf_slewctrl : 1;
           unsigned int conf_res_1 : 13;      // reserved
           unsigned int conf_res_2 : 12;      // reserved MSB
         } b;
} _CONF_MODULE_PIN;

#endif /* DATASTRUCT_H_ */
