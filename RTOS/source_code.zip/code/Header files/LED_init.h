/*
 * BeagleBoneIO_simpleLEDS.c
 *
 *  Created on: 24/04/2017
 *      Author: Samuel Ippolito
 */
#ifndef LED_INIT
#define LED_INIT

#include <stdlib.h>
#include <stdio.h>
#include <hw/inout.h>      // for in32() and out32();
#include <sys/mman.h>      // for mmap_device_io();
#include <sys/neutrino.h>  // for ThreadCtl( _NTO_TCTL_IO_PRIV , NULL);
#include <stdint.h>		   // for unit32 types
#include "client.h"


#define LED0	(1<<21)   // GPIO1_21
#define LED1	(1<<22)   // GPIO1_22
#define LED2	(1<<23)   // GPIO1_23
#define LED3	(1<<24)   // GPIO1_24

#define GPIO_OE        0x134
#define GPIO_DATAIN    0x138
#define GPIO_DATAOUT   0x13C

uintptr_t LED_init()
{
	printf("\nLED set up starts\n");

	// GPIO global pointers
	uintptr_t gpio1_base = NULL;

	//volatile uint32_t	val = 0;

	gpio1_base 	   = mmap_device_io(AM335X_GPIO_SIZE          , AM335X_GPIO1_BASE);

	if( !gpio1_base )
	{
		// An error has occurred
		perror("Can't map Control Base Module / GPIO Base");
		printf("Mapping IO ERROR! Main Terminated...!\n");
		return EXIT_SUCCESS;
	}
	printf("LED set up completes!\n");



	//munmap_device_io(gpio1_base, AM335X_GPIO_SIZE);

	//printf("Main Terminated...!\n");
	return gpio1_base;
}
void *strobingLED(void* data){
	int val;
	int gate;
	int light;
	uintptr_t gpio1_base = LED_init();
	TrainNodeDATA *td = (TrainNodeDATA*) data;
	while(1){
		val  = in32(gpio1_base + GPIO_DATAOUT); // read in current value
		val &= ~(LED0|LED1|LED2|LED3); // clear the bits that we might change

		switch(td->curState.state){
		case wait4train:
			gate = 0;
			light = 0;
			break;
		case trafficClearance:				// 4 bit data
			gate = 0;
			light = 2;						// 2 = 0010, use the second light for strobing
			break;
		case closeGate:
			gate = 1;						// 1 = 0001 use first LED to display the gate
			light = 2;
			break;
		case openGate:
			gate = 0;
			light = 2;
			break;
		}
		//strobing logic
		val |= ((gate|light)&0x0F)<<21;		// turn on both gate and light
		out32(gpio1_base + GPIO_DATAOUT, val); // write new value
		usleep(200000);
		val  = in32(gpio1_base + GPIO_DATAOUT); // read in current value
		val &= ~(LED0|LED1|LED2|LED3); // clear the bits that we might change
		val |= (gate&0x0F)<<21;				// only turn on the gate, light off
		out32(gpio1_base + GPIO_DATAOUT, val); // write new value
		usleep(200000);
	}
	munmap_device_io(gpio1_base, AM335X_GPIO_SIZE);
}
#endif
