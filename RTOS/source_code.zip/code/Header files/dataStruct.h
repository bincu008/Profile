#ifndef _CLIENT_H
#define _CLIENT_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/netmgr.h>
#include <sys/neutrino.h>
#include <fcntl.h>
#include <share.h>
#include <unistd.h>
#include "KEYPAD_init.h"
#include "timer.h"

//#define IMX
//#define BBB3
//#define BBB6
#define BBB7
//#define VM

#ifdef IMX
#define QNET_ATTACH_POINT  "/net/iMX6_Lab/dev/name/local/s244"

#elif defined(BBB3)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_03/dev/name/local/s244"

#elif defined(BBB6)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_06/dev/name/local/s244"

#elif defined(BBB7)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_07/dev/name/local/s244"

#elif defined(VM)
#define QNET_ATTACH_POINT "/net/QNX_SDP1/dev/name/local/s244"
#endif

#define BUF_SIZE 64

#define CLEARANCE_TIME 	 3
#define YELLOW_TIME  1
#define GREEN_TIME	 4

/*
 *  Macros of all node's internal events
 */


#define EVENT_TRIG_EW   8
#define EVENT_TRIG_NS	9
#define EVENT_UNTRIG_EW 10
#define EVENT_UNTRIG_NS 11
#define EVENT_NOTHING	0

/*
 *
 * Data structures for thread passing and send/reply content
 *
 */

typedef struct {
	struct _pulse hdr;
	int clientID;
	int data;
} sendData;

typedef struct {
	struct _pulse hdr;
	int cmd;
	double serv_time;
	double event_time;
} replyData;

typedef struct {
	sendData msg;
	replyData reply;
	double clkdiff;
	int data_ready;
	pthread_mutex_t mutex;
    pthread_cond_t cv;
    int finish;
} clientThreadData;
// train data struct
enum Boomstates {
	wait4train,
	trafficClearance,
	closeGate,
	openGate
};

typedef struct{
	enum Boomstates state;
	char input;
	//output result;
} modState;

typedef struct
{
	int fd;
	uint8_t Address;
	uint8_t mode;
	pthread_mutex_t mutex;
} LCD_connect;

typedef struct{
	int trainSENSOR;
	char state[20];
	char mode[20];
	LCD_connect td;
	modState curState;
	clientThreadData clientData;
} TrainNodeDATA;

typedef struct{
	int pedestrianSENSOR;
	char state[10];
	char event[9];
	char mode[9];
	LCD_connect td;

} internalDATA;



typedef union _CONF_MODULE_PIN_STRUCT   // See TRM Page 1420
{
  unsigned int d32;
  struct {    // name: field size
           unsigned int conf_mmode : 3;       // LSB
           unsigned int conf_puden : 1;
           unsigned int conf_putypesel : 1;
           unsigned int conf_rxactive : 1;
           unsigned int conf_slewctrl : 1;
           unsigned int conf_res_1 : 13;      // reserved
           unsigned int conf_res_2 : 12;      // reserved MSB
         } b;
} _CONF_MODULE_PIN;

/*
 *
 * Thread routines
 *
 */

void client_Handler(void *);

/*
 *
 * Function prototypes
 *
 */

double 	getCurrTime(void);

#endif /* _CLIENT_H */
