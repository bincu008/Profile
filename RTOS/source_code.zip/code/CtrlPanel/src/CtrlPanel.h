/*
 * CtrlPanel.h
 *
 *  Created on: 9Oct.,2019
 *      Author: s3707244
 */

#ifndef CTRLPANEL_H_
#define CTRLPANEL_H_

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <fcntl.h>
#include <share.h>
#include <time.h>

#define ATTACH_POINT "/net/RMIT_BBB_v5_07/dev/name/local/s244"

typedef struct
{
	struct _pulse hdr; // Our real data comes after this header
	int ClientID; // our data (unique id from client)
    int data;     // our data
} my_data;

typedef struct
{
	struct _pulse hdr;  // Our real data comes after this header
	int data;
    double clock; // Message we send back to clients to tell them the messages was processed correctly.
    double event;
} my_reply;



#endif /* CTRLPANEL_H_ */
