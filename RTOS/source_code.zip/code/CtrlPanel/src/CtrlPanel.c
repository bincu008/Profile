#include "CtrlPanel.h"

int main(void) {
	my_data msg;
	my_reply reply;

	msg.ClientID = 999; // unique number for this client (optional)

	int server_coid;

	printf("  ---> Trying to connect to server named: %s\n", ATTACH_POINT);
	if ((server_coid = name_open(ATTACH_POINT,0))==-1)
	{
		printf("\n    ERROR, could not connect to server!\n\n");
		return EXIT_FAILURE;
	}

	printf("Connection established to: %s\n", ATTACH_POINT);

	// We would have pre-defined data to stuff here
	msg.hdr.type = 0x00;
	msg.hdr.subtype = 0x00;


	// set up data packet
	msg.data=1;

	// the data we are sending is in msg.data
	printf("Client (ID:%d), sending data packet with the integer value: %d \n", msg.ClientID, msg.data);
	fflush(stdout);

	if (MsgSend(server_coid, &msg, sizeof(msg), &reply, sizeof(reply)) == -1)
	{
		printf(" Error data '%d' NOT sent to server\n", msg.data);
			// maybe we did not get a reply from the server
	}
	else
	{ // now process the reply
		printf("   -->Reply is: '%d'\n", reply.data);
		if(reply.data == 1){
			printf("Successful connection to server\n");
		}else{
			printf("Unknown error received from server\n");
		}
	}



	while(1){
		//check key presses
		char temp;
		scanf(" %c", &temp);
		if (temp == '5'){
			// set up data packet
			msg.data=5;

			// the data we are sending is in msg.data
			printf("Client (ID:%d), sending data packet with the integer value: %d \n", msg.ClientID, msg.data);
			fflush(stdout);

			if (MsgSend(server_coid, &msg, sizeof(msg), &reply, sizeof(reply)) == -1)
			{
				printf(" Error data '%d' NOT sent to server\n", msg.data);
					// maybe we did not get a reply from the server
			}
			else
			{ // now process the reply
				printf("   -->Reply is: '%d'\n", reply.data);
				if(reply.data == 5){
					printf("Change Mode Command Received\n");
				}else{
					printf("Unknown error received from server\n");
				}
			}
		}
	}

	// Close the connection
	printf("\n Sending message to server to tell it to close the connection\n");
	name_close(server_coid);

	return EXIT_SUCCESS;
}
