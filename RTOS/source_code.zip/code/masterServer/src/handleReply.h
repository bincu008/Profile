/*
 * handleReply.h
 *
 *  Created on: 5Oct.,2019
 *      Author: s3707244
 */

#ifndef SRC_HANDLEREPLY_H_
#define SRC_HANDLEREPLY_H_

#define SECOND 1000000000

#define INTERSECTIONONE 200
#define INTERSECTIONTWO 250

//this function handles the reply to client and sets the next event
//called from masterServer.c
//returns signal for next event
int handleReply(int msg, int clientID, client * nodes, int * initialised, event * store){
	switch(msg)
	{
		//connect clients (only happens once)
		case 1:
			printf("Connection Received from %d\n",clientID);
			//set to road client
			nodes[*initialised].clientID = clientID;
			nodes[*initialised].connected = 1;
			*initialised = *initialised + 1;
			store->client = clientID;
			//set first event once first client connects
			if(*initialised == 1){
				store->signal = 1;
				store->eventTime = getCurrTime() + (double)10*SECOND;
				store->modeSwitch = 0;
				store->currMode = 't';
			}
			//resync
			if(store->modeSwitch == 3){
				store->modeSwitch = 0;
				store->signal = 1;
				store->eventTime = getCurrTime() + (double)10*SECOND;
			}

			return 1;
			break;

		//Mode Change command
		case 5:
			//sensor to timed

			if(store->currMode == 's'){
				store->signal = 9; //force N-S first
				store->eventTime = getCurrTime() + SECOND;
				store->modeSwitch = 1; //this causes mode to switch after all lights N-S
				printf("Change Mode to Sensor\n");
			//timed to sensor
			}else{
				store->signal = 5;
				store->eventTime = getCurrTime() + SECOND; //switch in 1 second
				store->currMode = 's';

				printf("Change Mode to Sensor\n");
			}
			return 5;
			break;

		//binary sensor mode changes case 7-9
		case 7:
			//Change lights to E-W on one intersection
			if(store->currMode == 's' && store->modeSwitch != 2){ //check sensor mode and not blocked
				printf("%d sensor switched to EW Mode\n", clientID);
				store->signal = 7;
				store->eventTime = getCurrTime() + SECOND;
				store->client = clientID;
			}
			return 8;
			break;
		case 8:
			//Change lights to E-W
			if(store->currMode == 's' && store->modeSwitch != 2){ //check sensor mode and not blocked
				printf("Both sensor switched to EW Mode\n");
				store->signal = 8;
				store->eventTime = getCurrTime() + SECOND;
				store->client = clientID;
			}
			return 8;
			break;

		case 9:
			//Change lights to N-S
			if(store->currMode == 's' && store->modeSwitch != 2){ //check sensor mode and not blocked
				printf("Sensor switched to NS Mode\n");
				store->signal = 9;
				store->modeSwitch = 9;
				store->client = clientID;
				store->eventTime = getCurrTime() + SECOND;
			}
			return 9;
			break;

		//train cases
		case 12: //train coming
			printf("Train Approaching\n");
			//if(store->currMode == 's'){
				store->signal = 12; //E-W to clear traffic
				store->eventTime = getCurrTime() + SECOND;
				store->modeSwitch = 2; //block signals
			//}
			return 12;
			break;

		case 13: //train here
			printf("Train Crossing\n");
			//if(store->currMode == 's'){
				store->signal = 13; //N-S train coming
				store->eventTime = getCurrTime() + SECOND;
			//}
			return 13;
			break;

		case 14://train gone
			printf("Train Passed\n");
			//if(store->currMode == 's'){
				store->modeSwitch = 0; //unblock
			//}
			return 14;
			break;

		//Respond to standard Poll
		case 88:
			//check if event time has passed, reset event if it has expired
			if (store->eventTime <= getCurrTime()){
				//special case for mode switch after forcing N-S
				if(store->modeSwitch == 1){
					store->signal = 5;
					//time 3 seconds from now
					store->eventTime = getCurrTime() + (double)3*SECOND;

					//get ready for resync
					if(store->client == INTERSECTIONONE || store->client == INTERSECTIONTWO){
						store->modeSwitch = 3;
					//no resync needed
					}else{
						store->modeSwitch = 0;
					}

					//check what to switch to
					if(store->currMode == 't'){
						store->currMode = 's';
					}else{
						store->currMode = 't';
					}
					return 5;
				}
				//get ready for late connect/resync
				if (store->signal == 1){
					store->modeSwitch = 3;
				}
				//clear expired nodeSwitch
				if(store->modeSwitch == 9){
					store->modeSwitch = 0;
				}
				//event expired normally, change to no event
				store->signal = 88;
				store->eventTime = 0;
				store->client = 0;
				return 88;
			}else{

				if (store->signal == 7){
					if(clientID == store->client){
					//special case for only single e-w change
						return 8;
					}else{
						return 88; //ignore irrelevant client
					}
				}else if(store->signal == 9 && store->modeSwitch == 9){
					if(store->client == clientID){
						//return for relevant client
						return 9;
					}else{
						//return nothing for irrelevant client
						return 88;
					}
				}else{
					//still waiting on event to happen so return the next event
					return store->signal;
				}
			}
			break;
		//unknown number received, return an error
		default:
			printf("Unknown value received\n");
			return 0;
			break;
	}
	return 0;
}

#endif /* SRC_HANDLEREPLY_H_ */
