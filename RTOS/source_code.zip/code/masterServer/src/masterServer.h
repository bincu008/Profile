/*
 * masterServer.h
 *
 *  Created on: 5Oct.,2019
 *      Author: s3707244
 */

#ifndef SRC_MASTERSERVER_H_
#define SRC_MASTERSERVER_H_

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <semaphore.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <fcntl.h>
#include <share.h>
#include <time.h>



#define ATTACH_POINT "s244"

#define NUM_NODES 4

typedef struct
{
	struct _pulse hdr; // Our real data comes after this header
	int ClientID; // our data (unique id from client)
    int data;     // our data
} my_data;

typedef struct
{
	struct _pulse hdr;  // Our real data comes after this header
	int data;
    double clock;
    double event;
} my_reply;

//used to store which clients connected
typedef struct
{
	int clientID;
	int connected;
} client;

//used to store next event and other details for server
typedef struct{
	int signal;
	double eventTime;
	int client;
	int modeSwitch;
	char currMode; // 's' or 't'
} event;

// prototypes
int server();
int handleReply(int msg, int clientID, client * nodes, int * initialised, event * store);


#endif /* SRC_MASTERSERVER_H_ */
