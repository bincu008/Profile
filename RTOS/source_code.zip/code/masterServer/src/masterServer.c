#include "masterServer.h"
#include "srvFunction.h"
#include "handleReply.h"

int main(int argc, char *argv[])
{

	printf("Server running\n");

    int ret = 0;
    ret = server();

	printf("Main (Server) Terminated....\n");
	return ret;
}

/*** Server code ***/
int server()
{
   name_attach_t *attach;

   //attach to local point
   if ((attach = name_attach(NULL, ATTACH_POINT, 0)) == NULL)
   {
       printf("\nFailed to name_attach on ATTACH_POINT: %s \n", ATTACH_POINT);
       printf("\n Possibly another server with the same name is already running !\n");
	   return EXIT_FAILURE;
   }

   printf("Server Listening for Clients on ATTACH_POINT: %s \n", ATTACH_POINT);


   my_data msg;
   int rcvid=0, msgnum=0;
   //initialize reply
   my_reply replymsg;
   replymsg.hdr.type = 0x01;
   replymsg.hdr.subtype = 0x00;

   //set user tracking variables
   client nodes[NUM_NODES];
   int joined = 0;
   event store;

   while (1)
   {
	   // Do your MsgReceive's here now with the chid
       rcvid = MsgReceive(attach->chid, &msg, sizeof(msg), NULL);

       if (rcvid == -1)  // Error condition, exit
       {
           printf("\nFailed to MsgReceive\n");
           break;
       }

       // did we receive a Pulse or message?
       // for Pulses:
       if (rcvid == 0)  //  Pulse received, work out what type
       {
           switch (msg.hdr.code)
           {
			   case _PULSE_CODE_DISCONNECT:
					// A client disconnected all its connections by running
					// name_close() for each name_open()  or terminated
				   printf("\nClientID:%d detached ...\n", msg.ClientID);
				   if(store.currMode == 's'){
					   store.signal = 9; //force N-S first
					   store.eventTime = getCurrTime() + SECOND;
					   store.modeSwitch = 1; //this causes mode to switch after all lights N-S
					   store.client = msg.ClientID;
					   printf("\nForced transition to timed mode due to disconnect\n");
					   joined--;
				   }else{
					   store.modeSwitch = 3; //this causes mode to resync after reconnect
					   store.client = msg.ClientID;
				   }
				   break;

			   case _PULSE_CODE_UNBLOCK:
					// REPLY blocked client wants to unblock (was hit by a signal
					// or timed out).  It's up to you if you reply now or later.
				   printf("\nServer got _PULSE_CODE_UNBLOCK after %d, msgnum\n", msgnum);
				   break;

			   case _PULSE_CODE_COIDDEATH:  // from the kernel
				   printf("\nServer got _PULSE_CODE_COIDDEATH after %d, msgnum\n", msgnum);
				   break;

			   case _PULSE_CODE_THREADDEATH: // from the kernel
				   printf("\nServer got _PULSE_CODE_THREADDEATH after %d, msgnum\n", msgnum);
				   break;

			   default:
				   // Some other pulse sent by one of your processes or the kernel
				   printf("\nServer got some other pulse after %d, msgnum\n", msgnum);
				   break;

           }
           continue;// go back to top of while loop
       }

       // for messages:
       if(rcvid > 0) // if true then A message was received
       {
		   msgnum++;

		   // If the Global Name Service (gns) is running, name_open() sends a connect message. The server must EOK it.
		   if (msg.hdr.type == _IO_CONNECT )
		   {
			   MsgReply( rcvid, EOK, NULL, 0 );
			   printf("\n gns service is running....");
			   continue;	// go back to top of while loop
		   }

		   // Some other I/O message was received; reject it
		   if (msg.hdr.type > _IO_BASE && msg.hdr.type <= _IO_MAX )
		   {
			   MsgError( rcvid, ENOSYS );
			   printf("\n Server received and IO message and rejected it....");
			   continue;	// go back to top of while loop
		   }

		   // A message was received
		   printf("Server received data packet with value of '%d' from client (ID:%d)\n", msg.data, msg.ClientID);
		   fflush(stdout);
		   replymsg.data = handleReply(msg.data, msg.ClientID, nodes, &joined, &store); //send msg data to be handled by reply
		   printf("Server replied %d \n",replymsg.data);

		   //special case for E-W signal 1 second delay
		   if(replymsg.data == 8 && msg.ClientID != store.client){
			   replymsg.event = store.eventTime + 3000000000;
		   }else{
			   replymsg.event = store.eventTime;
		   }

		   //send curr server time for synchronisation
		   replymsg.clock = getCurrTime();

		   //send full command
		   MsgReply(rcvid, EOK, &replymsg, sizeof(replymsg));
       }
       else
       {
		   printf("\nERROR: Server received something, but could not handle it correctly\n");
       }
   }

   // Delete system attach point
   name_detach(attach, 0);

   return EXIT_SUCCESS;
}




