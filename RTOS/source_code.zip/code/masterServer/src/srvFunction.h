/*
 * srvFunction.h
 *
 *  Created on: 5Oct.,2019
 *      Author: s3707244
 */

#ifndef SRC_SRVFUNCTION_H_
#define SRC_SRVFUNCTION_H_

//gets current time and returns double
double getCurrTime(){
	struct timespec var;
	if( clock_gettime( CLOCK_MONOTONIC, &var) == -1 ) {
	  perror( "clock gettime" );
	  return EXIT_FAILURE;
	}
	double time = ((double)var.tv_sec * 1000000000) + (double)var.tv_nsec;
	return time;
}

#endif /* SRC_SRVFUNCTION_H_ */
