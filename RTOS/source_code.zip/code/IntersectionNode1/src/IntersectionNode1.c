#include "IntersectionNode1.h"

/*
 *
 * Global variables
 *
 */

static int synchronized = 1;
static int run_once = 1;		// Flag set to make the LCD print only once per state

/*
 *
 * Thread routine definitions
 *
 */

void LCDthread_A_ex (void *data)
{
	clientThreadData *td = (clientThreadData *) data;
	uint8_t	LCDdata[20] = {};

	while(1)
	{
		if(synchronized) pthread_mutex_lock(&td->lcd.mutex);     //lock the function to make sure the variables are protected
			// write some Text to the LCD screen
			SetCursor(td->lcd.fd, td->lcd.Address,0,0); // set cursor on LCD to first position first line
			memcpy(LCDdata, td->LCD_bufferA, 20);	  //state
			I2cWrite_(td->lcd.fd, td->lcd.Address, DATA_SEND, &LCDdata[0], sizeof(LCDdata));		// write new data to I2C
		if(synchronized) pthread_mutex_unlock(&td->lcd.mutex);	//unlock the functions to release the variables for use by other functions
		usleep(250000); // update every 250 ms
	}
}

void LCDthread_B_ex (void *data)
{
	clientThreadData *td = (clientThreadData *) data;
	uint8_t	LCDdata[20] = {};

	while(1)
	{
		if(synchronized) pthread_mutex_lock(&td->lcd.mutex);     //lock the function to make sure the variables are protected
			// write some Text to the LCD screen
			SetCursor(td->lcd.fd, td->lcd.Address,1,0); // set cursor on LCD to first position first line
			memcpy(LCDdata, td->LCD_bufferB, 20);	  //state
			I2cWrite_(td->lcd.fd, td->lcd.Address, DATA_SEND, &LCDdata[0], sizeof(LCDdata));		// write new data to I2C
		if(synchronized) pthread_mutex_unlock(&td->lcd.mutex);	//unlock the functions to release the variables for use by other functions
		usleep(250000);
	}
}

void client_Handler(void *data)
{
	clientThreadData *client = (clientThreadData *)data;
	enum client_states curState = Connect;
	int server_coid;
	double cli_time ;
	FILE *logfd;
	time_t now;
	pthread_t delayThread;
	delayThreadData delay;

	timer_init(&delay.timer);
	logfd = fopen("client.log", "w");

	delay.val = 0.2;
	client->msg.clientID = CLIENT_ID;		// Any unique number as ID (optional)
	client->msg.hdr.type = 0x00;
	client->msg.hdr.subtype = 0x00;
	client->msg.data = 1;

	while (1)
	{
		switch (curState) {
		case Connect:
			printf("Connecting to server...\n");

#ifdef USE_LCD
			pthread_mutex_lock(&client->lcd.mutex);
			memcpy(&client->LCD_bufferA[16], "Sv:N", 4);
			pthread_mutex_unlock(&client->lcd.mutex);
#endif

			if ((server_coid = name_open(QNET_ATTACH_POINT, 0)) == -1) {
				printf("ERROR_OPEN: %s\n", strerror(errno));
				curState = Connect;
				sleep(1);
				break;
			}
			printf("Connection established to server ID %d\n", server_coid);
			curState = Confirm;

			break;

		case Confirm:
			// Server send back data = 1 to confirm the connection
			if (MsgSend(server_coid, &client->msg, sizeof(client->msg), &client->reply, sizeof(client->reply)) == -1) {
				printf("ERROR_SEND: %s", strerror(errno));
				curState = Connect;
				break;
			}

			// Take the difference between 2 devices' clocks as offset
			client->clkdiff = client->reply.serv_time - getCurrTime();
			printf("Server ready!\n");
#ifdef USE_LCD
			pthread_mutex_lock(&client->lcd.mutex);
			memcpy(&client->LCD_bufferA[16], "Sv:Y", 4);
			pthread_mutex_unlock(&client->lcd.mutex);
#endif

			// Signal the state machine to start cycling through to NSGreen
			// After deadline, signal the state machine to proceed as usual.
			pthread_mutex_lock(&client->mutex);
			client->sigchange = 3;
			pthread_mutex_unlock(&client->mutex);
			cli_time = waitForDeadline(client->reply.event_time, client->clkdiff);
			pthread_mutex_lock(&client->mutex);
			client->sigchange = 4;
			pthread_mutex_unlock(&client->mutex);

			curState = Messaging;

			break;

		case Messaging:
			pthread_create(&delayThread, NULL, (void *)timer_thread_delay, &delay);
			pthread_mutex_lock(&client->input.mutex);
			if (client->input.event != 0)
				client->msg.data = client->input.event;
			else
				client->msg.data = 88;
			client->input.event = 0;
			pthread_mutex_unlock(&client->input.mutex);

			if (MsgSend(server_coid, &client->msg, sizeof(client->msg),
						&client->reply, sizeof(client->reply)) == -1) {
				printf("ERROR_SEND: %s\n", strerror(errno));

				pthread_mutex_lock(&client->mutex);
				client->opmode = Mode_Timed;
				pthread_mutex_unlock(&client->mutex);

#ifdef USE_LCD
				pthread_mutex_lock(&client->lcd.mutex);
				memcpy(&client->LCD_bufferB[16], "Time", 4);
				pthread_mutex_unlock(&client->lcd.mutex);
#endif

				printf("--> Mode default to Mode_Timed\n");
				curState = Connect;
				break;
			}

			switch(client->reply.cmd)
			{
			case 0:
				printf("--> Server reporting some error\n");
				break;
			case 1:
				// Other node reconnect
				// Run timed mode until NSClearance then enter NSGreenSync
				// Wait until deadline on NSGreenSync then enter NSGreen
				// The main thread is signaled the start and end of this process
				// by signal 3 (start) and 4 (end)
#ifdef USE_LCD
				pthread_mutex_lock(&client->lcd.mutex);
				memcpy(&client->LCD_bufferB[16], "Sync", 4);
				pthread_mutex_unlock(&client->lcd.mutex);
#endif

				pthread_mutex_lock(&client->mutex);
				client->sigchange = 3;
				pthread_mutex_unlock(&client->mutex);
				cli_time = waitForDeadline(client->reply.event_time, client->clkdiff);
				pthread_mutex_lock(&client->mutex);
				client->sigchange = 4;
				pthread_mutex_unlock(&client->mutex);

#ifdef USE_LCD
				pthread_mutex_lock(&client->lcd.mutex);
				memcpy(&client->LCD_bufferB[16], "Time", 4);
				pthread_mutex_unlock(&client->lcd.mutex);
#endif

				break;
			case 5:
				cli_time = waitForDeadline(client->reply.event_time, client->clkdiff);
				pthread_mutex_lock(&client->mutex);
				client->opmode = (client->opmode == Mode_Timed) ? Mode_Sensor : Mode_Timed;
				pthread_mutex_unlock(&client->mutex);

				if (client->opmode == Mode_Timed) {
					printf("--> Mode switch to Sensor Mode\n");
#ifdef USE_LCD
					pthread_mutex_lock(&client->lcd.mutex);
					memcpy(&client->LCD_bufferB[16], "Sens", 4);
					pthread_mutex_unlock(&client->lcd.mutex);
#endif
				}
				else {
					printf("--> Mode switch to Timed Mode\n");
#ifdef USE_LCD
					pthread_mutex_lock(&client->lcd.mutex);
					memcpy(&client->LCD_bufferB[16], "Time", 4);
					pthread_mutex_unlock(&client->lcd.mutex);
#endif
				}
				break;
			case 8:
				cli_time = waitForDeadline(client->reply.event_time, client->clkdiff);
				pthread_mutex_lock(&client->mutex);
				client->sigchange = 1;
				pthread_mutex_unlock(&client->mutex);
				break;
			case 9:
				cli_time = waitForDeadline(client->reply.event_time, client->clkdiff);
				pthread_mutex_lock(&client->mutex);
				client->sigchange = 2;
				pthread_mutex_unlock(&client->mutex);
				break;
			case 12:
				pthread_mutex_lock(&client->mutex);
				client->sigchange = 5;
				pthread_mutex_unlock(&client->mutex);
#ifdef USE_LCD
				pthread_mutex_lock(&client->lcd.mutex);
				memcpy(&client->LCD_bufferB[16], "Trn!", 4);
				pthread_mutex_unlock(&client->lcd.mutex);
#endif
				break;
			case 13:
				pthread_mutex_lock(&client->mutex);
				client->sigchange = 6;
				pthread_mutex_unlock(&client->mutex);
				break;
			case 14:
				pthread_mutex_lock(&client->mutex);
				client->sigchange = 7;
				pthread_mutex_unlock(&client->mutex);
				break;
			case 88:
				break;
			default:
				printf("! Not a mapped command\n");
				break;
			}
			timer_thread_sync(delayThread);
			curState = Messaging;

			break;

		default:
			break;
		}

		time(&now);
		fprintf(logfd, "-- %s --\nSent %d. Received %d, %f, %f.\nClient time %f\n", ctime(&now),
				client->msg.data, client->reply.cmd, client->reply.event_time, client->reply.serv_time, cli_time);

	}

	fclose(logfd);
	printf("\nClosing connection...\n");
	pthread_exit((void *)EXIT_SUCCESS);
}

void input_Handler(void *data)
{
	inputThreadData *input = (inputThreadData *)data;
	uintptr_t gpio1_base = KEYPAD_init();
	int keyval, last_keyval = 0;
	volatile uint32_t rawval = 0;

	while (1) {
		InterruptWait(0, NULL);

		volatile uint32_t word = 0;
		rawval = KeypadReadIObit(gpio1_base, SD0);

		if (rawval == 0) {
			word = 0;
			delaySCL();

			for (int i = 0; i < 16; i++) {
				strobe_SCL(gpio1_base);

				rawval = KeypadReadIObit(gpio1_base, SD0);
				rawval = ~rawval & 0x01;
				word = word | (rawval << i);
			}

			keyval = DecodeKeyValue(word);
			pthread_mutex_lock(&input->mutex);
			switch(keyval) {
			case 0:
				switch (last_keyval) {
					case 1:
						printf("[ N Sensor released ]\n");
						input->event = 11;
						break;
					case 2:
						printf("[ S Sensor released ]\n");
						input->event = 11;
						break;
					case 3:
						printf("[ outside E-W Sensor released ]\n");
						input->event = 10;
						break;
					case 4:
						printf("[ inside E-W Sensor released ]\n");
						input->event = 10;
						break;
					case 5:
						printf("[ N Pedestrian released ]\n");
						break;
					case 6:
						printf("[ S Pedestrian released ]\n");
						break;
					case 7:
						printf("[ E Pedestrian released ]\n");
						break;
					case 8:
						printf("[ W Pedestrian released ]\n");
						break;
				}
				break;
			case 1:
				printf("[ N Sensor triggered ]\n");
				input->event = 9;
				break;
			case 2:
				printf("[ S Sensor triggered ]\n");
				input->event = 9;
				break;
			case 3:
				printf("[ outside E-W Sensor triggered ]\n");
				input->event = 8;
				break;
			case 4:
				printf("[ inside E-W Sensor triggered ]\n");
				input->event = 7;
				break;
			case 5:
				printf("[ N Pedestrian pressed ]\n");
				input->event = 9;
				break;
			case 6:
				printf("[ S Pedestrian pressed ]\n");
				input->event = 9;
				break;
			case 7:
				printf("[ E Pedestrian pressed ]\n");
				input->event = 7;
				break;
			case 8:
				printf("[ W Pedestrian pressed ]\n");
				input->event = 7;
				break;
			default:
				printf("[ Unmapped event ]\n");
				break;
			}
			pthread_mutex_unlock(&input->mutex);
			last_keyval = keyval;
		}
	}
}

/*
 *
 * Function definitions
 *
 */

double getCurrTime(){
	struct timespec var;
	double time;

	if( clock_gettime( CLOCK_REALTIME, &var) == -1 ) {
		perror( "clock_gettime error: " );
		return EXIT_FAILURE;
	}
	time = ((double)var.tv_sec * 1000000000) + (double)var.tv_nsec;

	return time;
}

double waitForDeadline(double deadline, double clkdiff)
{
	double ct;
	while ((ct = (getCurrTime() + clkdiff)) <= deadline)
		usleep(1000);

	return ct;
}

void IntersectionNodeFSM(enum light_states *CurState,
						 clientThreadData *client,
						 timerData *timer)
{
	switch (*CurState) {
	case Initialize:
		*CurState = Initialize_Handler(timer, client);
		break;
	case NSClearance:
		*CurState = NSClearance_Handler(timer, client);
		break;
	case NSGreen:
		*CurState = NSGreen_Handler(timer, client);
		break;
	case NSGreenSync:
		*CurState = NSGreenSync_Handler(timer, client);
		break;
	case NSYellow:
		*CurState = NSYellow_Handler(timer, client);
		break;
	case EWClearance:
		*CurState = EWClearance_Handler(timer, client);
		break;
	case EWGreen:
		*CurState = EWGreen_Handler(timer, client);
		break;
	case EWYellow:
		*CurState = EWYellow_Handler(timer, client);
		break;
	default:
		*CurState = Initialize;
		break;
	}
}

/*
 *
 *
 */

enum light_states Initialize_Handler(timerData *timer, clientThreadData *client)
{
	enum light_states NextState = NSClearance;

	if (run_once) {
		printf("[State 0] [EW: RED   ] [NS: RED   ]\n");
#ifdef USE_LCD
		pthread_mutex_lock(&client->lcd.mutex);
		memcpy(client->LCD_bufferA, "EW L[R];NS L[R]", 15);
		memcpy(client->LCD_bufferB, "EW P[D];NS P[D]", 15);
		pthread_mutex_unlock(&client->lcd.mutex);
#endif
		run_once = 0;
	}

	pthread_mutex_lock(&client->mutex);
	if (client->sigchange == 3) {
		NextState = NSClearance;
		run_once = 1;
	}
	else
		NextState = Initialize;
	pthread_mutex_unlock(&client->mutex);

	return NextState;
}

enum light_states NSClearance_Handler(timerData *timer, clientThreadData *client)
{
	enum light_states NextState = NSGreen;

	printf("[State 1] [EW: RED   ] [NS: RED   ]\n");
#ifdef USE_LCD
	pthread_mutex_lock(&client->lcd.mutex);
	memcpy(client->LCD_bufferA, "EW L[R];NS L[R]", 15);
	memcpy(client->LCD_bufferB, "EW P[D];NS P[D]", 15);
	pthread_mutex_unlock(&client->lcd.mutex);
#endif

	timer_delay(timer, CLEARANCE_TIME);

	pthread_mutex_lock(&client->mutex);
	if (client->sigchange == 3) {
		NextState = NSGreenSync;
		client->sigchange = 0;
	}
	else
		NextState = NSGreen;
	pthread_mutex_unlock(&client->mutex);

	return NextState;
}

enum light_states NSGreen_Handler(timerData *timer, clientThreadData *client)
{
	enum light_states NextState = NSYellow;
	ControlMode mode;
	double delaytime = ACTIVE_GREEN_TIME;

	if (run_once) {
		printf("[State 2] [EW: RED   ] [NS: GREEN ]\n");
#ifdef USE_LCD
		pthread_mutex_lock(&client->lcd.mutex);
		memcpy(client->LCD_bufferA, "EW L[R];NS L[G]", 15);
		memcpy(client->LCD_bufferB, "EW P[D];NS P[W]", 15);
		pthread_mutex_unlock(&client->lcd.mutex);
#endif
		run_once = 0;
		timer_delay(timer, INITIAL_GREEN_TIME);
	}

	pthread_mutex_lock(&client->mutex);
	mode = client->opmode;
	pthread_mutex_unlock(&client->mutex);

	switch (mode)
	{
	case Mode_Timed:
		// Skip the timer delay after the initial delay
		// if the nodes are syncing (reduce the sync time)
		pthread_mutex_lock(&client->mutex);
		if (client->sigchange == 3 || client->sigchange == 5) {
			// This condition expedite the light phase
			// by skipping the rest of the delay time
			NextState = NSYellow;
			delaytime = 0.1;
		}
		else if (client->sigchange == 6) {
			// Loop on NSGreen state until train passed signal '7'
			NextState = NSGreen;
			delaytime = 0.1;
		}
		else {
			NextState = NSYellow;
		}

		pthread_mutex_unlock(&client->mutex);
		timer_delay(timer, delaytime);
		run_once = 1;
		break;
	case Mode_Sensor:
		pthread_mutex_lock(&client->mutex);
		if (client->sigchange == 1 || client->sigchange == 5 || client->sigchange == 7) {
			NextState = NSYellow;
			client->sigchange = 0;
			run_once = 1;
		}
		else
			NextState = NSGreen;
		pthread_mutex_unlock(&client->mutex);
		break;
	default:
		NextState = NSGreen;
	}

	return NextState;
}

enum light_states NSGreenSync_Handler(timerData *timer, clientThreadData *client)
{
	enum light_states NextState = NSGreen;

	if (run_once) {
		printf("[State 2S] [EW: RED   ] [NS: GREEN ]\n");
#ifdef USE_LCD
		pthread_mutex_lock(&client->lcd.mutex);
		memcpy(client->LCD_bufferA, "EW L[R];NS L[G]", 15);
		memcpy(client->LCD_bufferB, "EW P[D];NS P[D]", 15);
		pthread_mutex_unlock(&client->lcd.mutex);
#endif
		run_once = 0;
	}

	pthread_mutex_lock(&client->mutex);
	if (client->sigchange == 4) {
		NextState = NSGreen;
		client->sigchange = 0;
		run_once = 1;
	}
	else
		NextState = NSGreenSync;
	pthread_mutex_unlock(&client->mutex);

	return NextState;
}

enum light_states NSYellow_Handler(timerData *timer, clientThreadData *client)
{
	printf("[State 3] [EW: RED   ] [NS: YELLOW]\n");
#ifdef USE_LCD
	pthread_mutex_lock(&client->lcd.mutex);
	memcpy(client->LCD_bufferA, "EW L[R];NS L[Y]", 15);
	memcpy(client->LCD_bufferB, "EW P[D];NS P[C]", 15);
	pthread_mutex_unlock(&client->lcd.mutex);
#endif

	timer_delay(timer, YELLOW_TIME);

	return EWClearance;
}

enum light_states EWClearance_Handler(timerData *timer, clientThreadData *client)
{
	printf("[State 4] [EW: RED   ] [NS: RED   ]\n");
#ifdef USE_LCD
	pthread_mutex_lock(&client->lcd.mutex);
	memcpy(client->LCD_bufferA, "EW L[R];NS L[R]", 15);
	memcpy(client->LCD_bufferB, "EW P[D];NS P[D]", 15);
	pthread_mutex_unlock(&client->lcd.mutex);
#endif

	timer_delay(timer, CLEARANCE_TIME);

	return EWGreen;
}

enum light_states EWGreen_Handler(timerData *timer, clientThreadData *client)
{
	enum light_states NextState = EWYellow;
	ControlMode mode;
	double delaytime = ACTIVE_GREEN_TIME;

	if (run_once) {
		printf("[State 5] [EW: GREEN ] [NS: RED   ]\n");
#ifdef USE_LCD
		pthread_mutex_lock(&client->lcd.mutex);
		memcpy(client->LCD_bufferA, "EW L[G];NS L[R]", 15);
		memcpy(client->LCD_bufferB, "EW P[W];NS P[D]", 15);
		pthread_mutex_unlock(&client->lcd.mutex);
#endif
		run_once = 0;
		timer_delay(timer, INITIAL_GREEN_TIME);
	}

	pthread_mutex_lock(&client->mutex);
	mode = client->opmode;
	pthread_mutex_unlock(&client->mutex);

	switch (mode)
	{
	case Mode_Timed:
		pthread_mutex_lock(&client->mutex);
		if (client->sigchange == 3) {
			// At this point, the signal can be cleared to 0
			// Since we don't want NSGreen to be expedited
			NextState = EWYellow;
			delaytime = 0.1;
			client->sigchange = 0;
		}
		else if (client->sigchange == 5) {
			// Loop on EWGreen until train is passing signal '6'
			NextState = EWGreen;
			delaytime = 0.1;
			// Don't clear signal value
		}
		else
			NextState = EWYellow;

		pthread_mutex_unlock(&client->mutex);
		timer_delay(timer, delaytime);

		run_once = 1;
		break;
	case Mode_Sensor:
		pthread_mutex_lock(&client->mutex);
		if (client->sigchange == 2) {
			NextState = EWYellow;
			client->sigchange = 0;
			run_once = 1;
		}
		else if (client->sigchange == 3 || client->sigchange == 6) {
			NextState = EWYellow;
			run_once = 1;
		}
		else
			NextState = EWGreen;
		pthread_mutex_unlock(&client->mutex);
		usleep(100);
		break;
	default:
		NextState = EWGreen;
	}

	return NextState;
}

enum light_states EWYellow_Handler(timerData *timer, clientThreadData *client)
{
	printf("[State 6] [EW: YELLOW] [NS: RED   ]\n");
#ifdef USE_LCD
	pthread_mutex_lock(&client->lcd.mutex);
	memcpy(client->LCD_bufferA, "EW L[Y];NS L[R]", 15);
	memcpy(client->LCD_bufferB, "EW P[C];NS P[D]", 15);
	pthread_mutex_unlock(&client->lcd.mutex);
#endif

	timer_delay(timer, YELLOW_TIME);

	return NSClearance;
}

int main(void) {
	printf("Node running\n\n");

    void *ret;

    pthread_t 		 clientThread;
    pthread_t		 inputThread;
    pthread_t 		 lcdThreadA;
    pthread_t		 lcdThreadB;
    clientThreadData client;
	timerData 		 timer;

	enum light_states CurState = Initialize;

	pthread_mutex_init(&client.mutex, NULL);
	pthread_cond_init(&client.cv, NULL);
	pthread_mutex_init(&client.input.mutex, NULL);

	client.opmode = Mode_Timed;
	client.sigchange = 0;
	client.clkdiff = 0;
	client.data_ready = 0;
	client.input.event = 0;
	client.lcd = LCD_init();
	memset(client.LCD_bufferA, 0, 20);
	memset(client.LCD_bufferB, 0, 20);

	timer_init(&timer);

    pthread_create(&clientThread, NULL, (void *)client_Handler, &client);
    pthread_create(&inputThread, NULL, (void *)input_Handler, &client.input);
#ifdef USE_LCD
    pthread_create(&lcdThreadA, NULL, (void *)LCDthread_A_ex, &client);
    pthread_create(&lcdThreadB, NULL, (void *)LCDthread_B_ex, &client);
#endif

    /* Main system loop */

    while (1)
    {
		IntersectionNodeFSM(&CurState, &client, &timer);
		usleep(10000);
    }

    /* Join threads to finalize exit */

    pthread_join(inputThread, NULL);
	pthread_join(clientThread, &ret);

	pthread_mutex_destroy(&client.mutex);
	pthread_cond_destroy(&client.cv);
	pthread_mutex_destroy(&client.input.mutex);

	printf("Main (Server) Terminated....\n");

	return (int *)ret;
}



