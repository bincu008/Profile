/*
 * IntersectionNode1.h
 *
 *  Created on: 15 Oct.,2019
 *      Author: Phuc Nguyen
 *      Description: Header file for IntersectionNode1.c
 *      			 Contains shared data structures, state machine data structures
 *      			 and function declarations
 */

#ifndef INTERSECTIONNODE1_H_
#define INTERSECTIONNODE1_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/netmgr.h>
#include <sys/neutrino.h>
#include <fcntl.h>
#include <share.h>
#include <unistd.h>
#include "LCD_init.h"
#include "keypad.h"
#include "timer.h"

//#define IMX
//#define BBB2
//#define BBB3
#define BBB6
//#define BBB7
//#define VM

#ifdef IMX
#define QNET_ATTACH_POINT  "/net/iMX6_Lab/dev/name/local/s244"

#elif defined(BBB2)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_02/dev/name/local/s244"

#elif defined(BBB3)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_03/dev/name/local/s244"

#elif defined(BBB6)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_06/dev/name/local/s244"

#elif defined(BBB7)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_07/dev/name/local/s244"

#elif defined(VM)
#define QNET_ATTACH_POINT "/net/QNX_SDP1/dev/name/local/s244"
#endif

#define USE_LCD

#define CLIENT_ID		 200
#define BUF_SIZE  		 64

#define CLEARANCE_TIME 	 	 2
#define YELLOW_TIME  	 	 1
#define ACTIVE_GREEN_TIME	 4
#define INITIAL_GREEN_TIME	 2

/*
 *  Macros of all node's internal events
 */


/*
 *
 * Data structures for thread passing and send/reply content
 *
 */

typedef enum {
	Mode_Timed,
	Mode_Sensor,
} ControlMode;

typedef struct {
	struct _pulse hdr;
	int clientID;
	int data;
} sendData;

typedef struct {
	struct _pulse hdr;
	int cmd;
	double serv_time;
	double event_time;
} replyData;

typedef struct {
	int event;
	pthread_mutex_t mutex;
} inputThreadData;

typedef struct {
	sendData msg;
	replyData reply;
	int opmode;
	int sigchange;
	double clkdiff;
	inputThreadData input;
	LCD_connect lcd;
	uint8_t LCD_bufferA[20];
	uint8_t LCD_bufferB[20];
	int data_ready;				// Removable!
	pthread_mutex_t mutex;
    pthread_cond_t cv;
} clientThreadData;

/*
 *
 * State machine support types
 *
 */

enum light_states {
	Initialize,
	NSClearance,
	NSGreen,
	NSGreenSync,
	NSYellow,
	EWClearance,
	EWGreen,
	EWYellow,
};

enum client_states {
	Connect,
	Confirm,
	Messaging
};

/*
 *
 * Thread routines
 *
 */

void LCDthread_A_ex(void *);
void LCDthread_B_ex(void *);
void client_Handler(void *);
void input_Handler(void *);

/*
 *
 * Function prototypes
 *
 */

double 	getCurrTime(void);
double	waitForDeadline(double, double);
int 	readInput(uintptr_t );
void 	IntersectionNodeFSM(enum light_states *,
						 clientThreadData *,
						 timerData *);

/*
 *
 * State Handlers
 *
 */

enum light_states Initialize_Handler(timerData *, clientThreadData *);
enum light_states NSClearance_Handler(timerData *, clientThreadData *);
enum light_states NSGreen_Handler(timerData *, clientThreadData *);
enum light_states NSGreenSync_Handler(timerData *, clientThreadData *);
enum light_states NSYellow_Handler(timerData *, clientThreadData *);
enum light_states EWClearance_Handler(timerData *, clientThreadData *);
enum light_states EWGreen_Handler(timerData *, clientThreadData *);
enum light_states EWYellow_Handler(timerData *, clientThreadData *);

#endif /* INTERSECTIONNODE1_H_ */
