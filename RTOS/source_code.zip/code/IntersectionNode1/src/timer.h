/*
 * timer.h
 *
 *  Created on: 15Oct.,2019
 *      Author: root
 */

#ifndef TIMER_H_
#define TIMER_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>
#include <sys/netmgr.h>
#include <sys/neutrino.h>

/*
 *
 * Data structures for timer
 *
 */

typedef union {
	struct _pulse pulse;
} mymsg_t;

typedef struct {
	struct sigevent event;
	struct itimerspec itime;
	timer_t timer_id;
	int chid;
	int rcvid;
	mymsg_t msg;
} timerData;

typedef struct {
	timerData timer;
	double val;
} delayThreadData;

/*
 *
 * Function prototypes
 *
 */

int  timer_init(timerData *);
void timer_set(timerData *, double);
void timer_start(timerData *);
void timer_wait(timerData *);
void timer_delay(timerData *, double);
void timer_thread_delay(void *);
void timer_thread_sync(pthread_t);



#endif /* TIMER_H_ */
