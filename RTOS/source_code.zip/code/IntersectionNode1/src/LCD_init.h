/*
 * LCD_init.h
 *
 *  Created on: 15Oct.,2019
 *      Author: root
 */

#ifndef LCD_INIT_H
#define LCD_INIT_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <devctl.h>
#include <hw/i2c.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <sys/neutrino.h>

#define DATA_SEND 0x40  // sets the Rs value high
#define Co_Ctrl   0x00  // mode to tell LCD we are sending a single command

typedef struct
{
	int fd;
	uint8_t Address;
	uint8_t mode;
	pthread_mutex_t mutex;
} LCD_connect;


// Function prototypes
LCD_connect LCD_init(void);
int  I2cWrite_(int fd, uint8_t Address, uint8_t mode, uint8_t *pBuffer, uint32_t NbData);
void SetCursor(int fd, uint8_t LCDi2cAdd, uint8_t row, uint8_t column);
void Initialise_LCD (int fd, _Uint32t LCDi2cAdd);


/*void *LCDthread_B_ex (void *data)
{
	TrainNodeDATA *td = (TrainNodeDATA*) data;
	uint8_t	LCDdata[10] = {};

	while(1)
	{
		if(synchronized) pthread_mutex_lock(&td->td.mutex);     //lock the function to make sure the variables are protected
			// write some Text to the LCD screen
			SetCursor(td->td.fd, td->td.Address,0,10); // set cursor on LCD to first position first line
			if(td->trainSENSOR == 1){
				sprintf(LCDdata,"Pes   ");
			} else {
				sprintf(LCDdata,"no Pes");
			}

			I2cWrite_(td->td.fd, td->td.Address, DATA_SEND, &LCDdata[0], sizeof(LCDdata));		// write new data to I2C
		if(synchronized) pthread_mutex_unlock(&td->td.mutex);	//unlock the functions to release the variables for use by other functions
		//usleep(1000000); // 1.0 seconds
	}
	return 0;
}*/

/*void *LCDthread_D_ex (void *data)
{
	TrainNodeDATA *td = (TrainNodeDATA*) data;
	uint8_t	LCDdata[10] = {};

	while(1)
	{
		if(synchronized) pthread_mutex_lock(&td->td.mutex);     //lock the function to make sure the variables are protected
			// write some Text to the LCD screen
			SetCursor(td->td.fd, td->td.Address,1,10); // set cursor on LCD to first position first line
			sprintf(LCDdata,"Event");		//Event
			I2cWrite_(td->td.fd, td->td.Address, DATA_SEND, &LCDdata[0], sizeof(LCDdata));		// write new data to I2C
		if(synchronized) pthread_mutex_unlock(&td->td.mutex);	//unlock the functions to release the variables for use by other functions
		//usleep(1000000); // 1.0 seconds
	}
}*/

#endif /* LCD_INIT_H */
