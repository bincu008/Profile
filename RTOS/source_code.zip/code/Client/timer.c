#include "timer.h"

int timer_init(timerData *timer)
{
	timer->chid = ChannelCreate(0);
	timer->event.sigev_notify = SIGEV_PULSE;
	timer->event.sigev_coid = ConnectAttach(ND_LOCAL_NODE, 0, timer->chid, _NTO_SIDE_CHANNEL, 0);
	if (timer->event.sigev_coid == -1)
	{
		printf("ERROR_TIMER : %s\n", strerror(errno));
		return 0;
	}

	struct sched_param th_param;
	pthread_getschedparam(pthread_self(), NULL, &th_param);
	timer->event.sigev_priority = th_param.sched_curpriority;    // old QNX660 version getprio(0);
	timer->event.sigev_code = _PULSE_CODE_MINAVAIL;

	if (timer_create(CLOCK_REALTIME, &timer->event, &timer->timer_id) == -1)
	{
		printf("ERROR_TIMER : %s\n", strerror(errno));
		return 0;
	}

	return 1;
}

void timer_set(timerData *timer, double val_sec)
{
	// Split the integer part and fractional part
	timer->itime.it_value.tv_sec = (time_t)val_sec;
	timer->itime.it_value.tv_nsec = (long)((val_sec - (int)val_sec) * 1e9);
	timer->itime.it_interval.tv_sec = 0;
	timer->itime.it_interval.tv_nsec = 0;
}

void timer_start(timerData *timer)
{
	timer_settime(timer->timer_id, 0, &timer->itime, NULL);
}

void timer_wait(timerData *timer)
{
   timer->rcvid = MsgReceive(timer->chid, &timer->msg, sizeof(timer->msg), NULL);

   // Determine who the message came from
   if (timer->rcvid == 0)
	   // If it's this process
	   // means received a pulse, now check "code" field...
	   if (timer->msg.pulse.code == _PULSE_CODE_MINAVAIL)
		   // Correct pulse type
		   return;
}

void timer_delay(timerData *timer, double val)
{
	timer_set(timer, val);
	timer_start(timer);
	timer_wait(timer);
}

void timer_thread_delay(void *data)
{
	delayThreadData *delay = (delayThreadData *)data;

	timer_set(&delay->timer, delay->val);
	timer_start(&delay->timer);
	timer_wait(&delay->timer);

	pthread_exit(NULL);
}

void timer_thread_sync(pthread_t thread)
{
	pthread_join(thread, NULL);
}
