#include "client.h"

double getCurrTime(){
	struct timespec var;
	double time;

	if( clock_gettime( CLOCK_REALTIME, &var) == -1 ) {
		perror( "clock_gettime error: " );
		return EXIT_FAILURE;
	}
	time = ((double)var.tv_sec * 1000000000) + (double)var.tv_nsec;

	return time;
}

void client_Handler(void *data)
{
	clientThreadData *client = (clientThreadData *)data;
	int server_coid;
	int connected = 0;
	double cli_time;
	FILE *logfd;
	time_t now;
	pthread_t delayThread;
	delayThreadData delay;

	timer_init(&delay.timer);
	logfd = fopen("client.log", "w");

	delay.val = 0.2;
	client->msg.clientID = 200;		// Any unique number as ID (optional)
	client->msg.hdr.type = 0x00;
	client->msg.hdr.subtype = 0x00;
	client->msg.data = 1;

	printf("Connecting to server...\n");

	if ((server_coid = name_open(QNET_ATTACH_POINT, 0)) == -1) {
		printf("ERROR_OPEN: %s", strerror(errno));
		pthread_exit((void *)EXIT_FAILURE);
	}

	printf("Connection established to server ID %d\n", server_coid);

	// Server send back data = 1 to confirm the connection
	while (client->reply.cmd != 1) {
		if (MsgSend(server_coid, &client->msg, sizeof(client->msg), &client->reply, sizeof(client->reply)) == -1) {
			printf("ERROR_SEND: %s", strerror(errno));
			pthread_exit((void *)EXIT_FAILURE);
		}
	}

	printf("Server ready!\n");

	connected = 1;
	pthread_mutex_lock(&client->mutex);
	while (client->data_ready)
		pthread_cond_wait(&client->cv, &client->mutex);
	client->data_ready = 1;
	pthread_cond_signal(&client->cv);
	pthread_mutex_unlock(&client->mutex);

	// Take the difference between 2 devices' clocks as offset
	client->clkdiff = client->reply.serv_time - getCurrTime();

	while (connected) {
		pthread_create(&delayThread, NULL, (void *)timer_thread_delay, &delay);
		pthread_mutex_lock(&client->input.mutex);
		if (client->input.event != 0)
			client->msg.data = client->input.event;
		else
			client->msg.data = 88;
		client->input.event = 0;
		pthread_mutex_unlock(&client->input.mutex);

		if (MsgSend(server_coid, &client->msg, sizeof(client->msg),
					&client->reply, sizeof(client->reply)) == -1) {
			printf("ERROR_SEND: %s", strerror(errno));
			break;
		}

		// Hang the thread until the specified event time is reached
		// In the case of no event, event time = 0 and the loop terminate immediately
		while ((cli_time = (getCurrTime() + client->clkdiff)) <= client->reply.event_time)
			usleep(1000);

		pthread_mutex_lock(&client->mutex);
		switch(client->reply.cmd)
		{
		case 0:
			printf("--> Server reporting some error\n");
			break;
		case 5:
			client->opmode = (client->opmode == Mode_Timed) ? Mode_Sensor : Mode_Timed;
			printf("--> Mode switch to %s\n", (client->opmode == Mode_Timed) ? "Timed Mode" :
											  (client->opmode == Mode_Sensor) ? "Sensor Mode" : "undefined");
			break;
		case 8:
			client->sigchange = 1;
			break;
		case 9:
			client->sigchange = 2;
			break;
		case 88:
			printf("Nothing going on\n");
			break;
		default:
			printf("! Not a mapped command\n");
			break;
		}
		pthread_mutex_unlock(&client->mutex);

		time(&now);
		fprintf(logfd, "-- %s --\nSent %d. Received %d, %f, %f.\nClient time %f\n", ctime(&now),
				client->msg.data, client->reply.cmd, client->reply.event_time, client->reply.serv_time, cli_time);

		timer_thread_sync(delayThread);
	}

	fclose(logfd);
	printf("\nClosing connection...\n");
	pthread_exit((void *)EXIT_SUCCESS);
}

