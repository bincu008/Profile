#ifndef _CLIENT_H
#define _CLIENT_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/iofunc.h>
#include <sys/dispatch.h>
#include <sys/netmgr.h>
#include <sys/neutrino.h>
#include <fcntl.h>
#include <share.h>
#include <unistd.h>
#include "keypad.h"
#include "dataStruct.h"
#include "timer.h"

//#define IMX
//#define BBB3
#define BBB6
//#define BBB7
//#define VM

#ifdef IMX
#define QNET_ATTACH_POINT  "/net/iMX6_Lab/dev/name/local/s244"

#elif defined(BBB3)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_03/dev/name/local/s244"

#elif defined(BBB6)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_06/dev/name/local/s244"

#elif defined(BBB7)
#define QNET_ATTACH_POINT "/net/RMIT_BBB_v5_07/dev/name/local/s244"

#elif defined(VM)
#define QNET_ATTACH_POINT "/net/QNX_SDP1/dev/name/local/s244"
#endif

#define BUF_SIZE 64

#define CLEARANCE_TIME 	 3
#define YELLOW_TIME  1
#define GREEN_TIME	 4

/*
 *  Macros of all node's internal events
 */


#define EVENT_TRIG_EW   8
#define EVENT_TRIG_NS	9
#define EVENT_UNTRIG_EW 10
#define EVENT_UNTRIG_NS 11
#define EVENT_NOTHING	0

/*
 *
 * Data structures for thread passing and send/reply content
 *
 */

typedef struct {
	struct _pulse hdr;
	int clientID;
	int data;
} sendData;

typedef struct {
	struct _pulse hdr;
	int cmd;
	double serv_time;
	double event_time;
} replyData;

typedef struct {
	int event;
	pthread_mutex_t mutex;
} inputThreadData;

typedef struct {
	sendData msg;
	replyData reply;
	int opmode;
	int sigchange;
	double clkdiff;
	inputThreadData input;
	int data_ready;
	pthread_mutex_t mutex;
    pthread_cond_t cv;
    int finish;
} clientThreadData;

/*
 *
 * Thread routines
 *
 */

void client_Handler(void *);
void input_Handler(void *);

/*
 *
 * Function prototypes
 *
 */

double 	getCurrTime(void);

#endif /* _CLIENT_H */
